// ======================================================
// KickCulture — Script.js (54 Products, INR, Full Checkout)
// ======================================================

const products = [
    // ============ NIKE (18 items) ============
    { id: 1, name: "Air Max 90", brand: "nike", type: "sneaker", price: 8999, originalPrice: 10999, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/i1-665455a5-45de-40fb-945f-c1852b82400d/react-infinity-run-flyknit-mens-running-shoe-zX42Nc.jpg" },
    { id: 2, name: "Air Force 1 '07", brand: "nike", type: "casual", price: 7499, originalPrice: null, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/i1-5cc7de3b-2afc-49c2-a1e4-0508997d09e6/react-miler-mens-running-shoe-DgF6nr.jpg" },
    { id: 3, name: "Dunk Low Retro", brand: "nike", type: "sneaker", price: 8299, originalPrice: 9999, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/i1-33b0a0a5-c171-46cc-ad20-04a768703e47/air-zoom-pegasus-37-womens-running-shoe-Jl0bDf.jpg" },
    { id: 4, name: "Blazer Mid '77", brand: "nike", type: "lifestyle", price: 7999, originalPrice: null, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/99a7d3cb-e40c-4474-91c2-0f2e6d231fd2/joyride-run-flyknit-womens-running-shoe-HcfnJd.jpg" },
    { id: 5, name: "Air Jordan 1 High OG", brand: "nike", type: "sneaker", price: 14999, originalPrice: 18999, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/9dda6202-e2ff-4711-9a09-0fcb7d90c164/mercurial-vapor-13-elite-fg-firm-ground-soccer-cleat-14MsF2.jpg" },
    { id: 6, name: "React Infinity Run 3", brand: "nike", type: "running", price: 10999, originalPrice: null, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/s1amp7uosrn0nqpsxeue/phantom-vision-elite-dynamic-fit-fg-firm-ground-soccer-cleat-19Kv1V.jpg" },
    { id: 7, name: "Air Max 97 Silver", brand: "nike", type: "sneaker", price: 12999, originalPrice: 15999, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/whegph8z9ornhxklc8rp/phantom-venom-academy-fg-firm-ground-soccer-cleat-6JVNll.jpg" },
    { id: 8, name: "ZoomX Vaporfly NEXT%", brand: "nike", type: "running", price: 17999, originalPrice: null, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/vhbwnkor8sxt8qtecgia/mercurial-vapor-13-elite-tech-craft-fg-firm-ground-soccer-cleat-l38JPj.jpg" },
    { id: 9, name: "Air Huarache", brand: "nike", type: "lifestyle", price: 9499, originalPrice: 11999, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/i1-a52a8aec-22dc-4982-961b-75c5f4c72805/mercurial-superfly-7-pro-mds-fg-firm-ground-soccer-cleat-mhcpdN.jpg" },
    { id: 10, name: "Pegasus 40", brand: "nike", type: "running", price: 9999, originalPrice: null, image: "https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/178b2a46-3ee4-492b-882e-f71efdd53a36/air-force-1-big-kids-shoe-2zqp8D.jpg" },
    { id: 11, name: "Court Vision Low", brand: "nike", type: "casual", price: 5499, originalPrice: 6999, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/8439f823-86cf-4086-81d2-4f9ff9a66866/air-max-90-big-kids-shoe-1wzwJM.jpg" },
    { id: 12, name: "Air Max 270", brand: "nike", type: "lifestyle", price: 11999, originalPrice: null, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/i1-620aeb37-1b28-44b0-9b14-5572f8cbc948/air-max-90-ltr-big-kids-shoe-hdNLQ5.jpg" },
    { id: 13, name: "Metcon 9", brand: "nike", type: "sports", price: 10999, originalPrice: 13499, image: "https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/33888130-0320-41a1-ba53-a026decd8aa2/joyride-dual-run-big-kids-running-shoe-1HDJF8.jpg" },
    { id: 14, name: "Revolution 7", brand: "nike", type: "running", price: 3999, originalPrice: null, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/i1-73e54c0b-11a6-478b-9f90-bd97fcde872d/renew-run-big-kids-running-shoe-5Bpz93.jpg" },
    { id: 15, name: "Waffle One SE", brand: "nike", type: "casual", price: 8499, originalPrice: 9999, image: "https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/178b2a46-3ee4-492b-882e-f71efdd53a36/air-force-1-big-kids-shoe-2zqp8D.jpg" },
    { id: 16, name: "Air Presto", brand: "nike", type: "lifestyle", price: 9999, originalPrice: null, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/8439f823-86cf-4086-81d2-4f9ff9a66866/air-max-90-big-kids-shoe-1wzwJM.jpg" },
    { id: 17, name: "Free Run 5.0", brand: "nike", type: "running", price: 7999, originalPrice: 9499, image: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/i1-620aeb37-1b28-44b0-9b14-5572f8cbc948/air-max-90-ltr-big-kids-shoe-hdNLQ5.jpg" },
    { id: 18, name: "SB Dunk High Pro", brand: "nike", type: "sneaker", price: 10499, originalPrice: null, image: "https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/33888130-0320-41a1-ba53-a026decd8aa2/joyride-dual-run-big-kids-running-shoe-1HDJF8.jpg" },

    // ============ PUMA (18 items) ============
    { id: 19, name: "RS-X³ Puzzle", brand: "puma", type: "sneaker", price: 8999, originalPrice: 10999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/409092/02/sv01/fnd/IND/fmt/png" },
    { id: 20, name: "Suede Classic XXI", brand: "puma", type: "casual", price: 5999, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/409092/01/sv01/fnd/IND/fmt/png" },
    { id: 21, name: "Future Rider Play On", brand: "puma", type: "lifestyle", price: 6499, originalPrice: 7999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/408198/02/sv01/fnd/IND/fmt/png" },
    { id: 22, name: "Cell Venom Mesh", brand: "puma", type: "sports", price: 7999, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/396463/01/sv01/fnd/IND/fmt/png" },
    { id: 23, name: "Cali Dream Leather", brand: "puma", type: "casual", price: 7499, originalPrice: 8999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/402692/13/sv01/fnd/IND/fmt/png" },
    { id: 24, name: "Mirage Sport Remix", brand: "puma", type: "sneaker", price: 7999, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/309235/03/sv01/fnd/IND/fmt/png" },
    { id: 25, name: "Velocity Nitro 2", brand: "puma", type: "running", price: 9499, originalPrice: 11999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/309174/01/sv01/fnd/IND/fmt/png" },
    { id: 26, name: "Deviate Nitro 2", brand: "puma", type: "running", price: 12999, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/406203/03/sv01/fnd/IND/fmt/png" },
    { id: 27, name: "Palermo Leather", brand: "puma", type: "casual", price: 6999, originalPrice: 7999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/403307/01/sv01/fnd/IND/fmt/png" },
    { id: 28, name: "Slipstream Lo Retro", brand: "puma", type: "sneaker", price: 7499, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/402701/01/sv01/fnd/IND/fmt/png" },
    { id: 29, name: "Rider FV Future Vintage", brand: "puma", type: "lifestyle", price: 5999, originalPrice: 7499, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/405596/01/sv01/fnd/IND/fmt/png" },
    { id: 30, name: "SOFTRIDE Enzo Evo", brand: "puma", type: "running", price: 4999, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/309140/02/sv01/fnd/IND/fmt/png" },
    { id: 31, name: "Clyde All-Pro", brand: "puma", type: "sports", price: 10999, originalPrice: 13999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/394371/02/sv01/fnd/IND/fmt/png" },
    { id: 32, name: "X-Ray 2 Square", brand: "puma", type: "lifestyle", price: 5499, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/402185/05/sv01/fnd/IND/fmt/png" },
    { id: 33, name: "Smash v2 Leather", brand: "puma", type: "casual", price: 3999, originalPrice: 4999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/309234/02/sv01/fnd/IND/fmt/png" },
    { id: 34, name: "Fuse 2.0 Training", brand: "puma", type: "sports", price: 6999, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/402185/02/sv01/fnd/IND/fmt/png" },
    { id: 35, name: "Nano X3", brand: "puma", type: "sports", price: 8499, originalPrice: 9999, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/406002/05/sv01/fnd/IND/fmt/png" },
    { id: 36, name: "Electrify Nitro 2", brand: "puma", type: "running", price: 9999, originalPrice: null, image: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/308899/01/sv01/fnd/IND/fmt/png" },

    // ============ COMET (18 items) ============
    { id: 37, name: "X Lows Phantom", brand: "comet", type: "sneaker", price: 6999, originalPrice: 8499, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/designer_special_placement.jpg" },
    { id: 38, name: "APEX Runner", brand: "comet", type: "running", price: 7499, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/designer_special_placement_green_croc.jpg" },
    { id: 39, name: "Vanguard High-Top", brand: "comet", type: "sneaker", price: 8999, originalPrice: 10999, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/lateral.1jpg.jpg" },
    { id: 40, name: "Nebula Strider", brand: "comet", type: "running", price: 6999, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Lateral_7.jpg" },
    { id: 41, name: "X Lows Ivory", brand: "comet", type: "casual", price: 5999, originalPrice: 6999, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Lateral_1_253e065d-72de-43f0-bf65-f3b0ff1e8dd5.jpg" },
    { id: 42, name: "APEX Stealth Mode", brand: "comet", type: "sneaker", price: 7999, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/lat2.jpg" },
    { id: 43, name: "Drift Street", brand: "comet", type: "casual", price: 4999, originalPrice: 5999, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Lateralwhite.jpg" },
    { id: 44, name: "Blaze Sport", brand: "comet", type: "sports", price: 6499, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/01.jpg" },
    { id: 45, name: "Comet Zero Drop", brand: "comet", type: "running", price: 8499, originalPrice: 9999, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Lateral_5.jpg" },
    { id: 46, name: "AEON V2 Classic", brand: "comet", type: "lifestyle", price: 7499, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Lateral_4_1_da4a0672-4105-402c-8c09-79e65b7b668a.jpg" },
    { id: 47, name: "ALTER Edge", brand: "comet", type: "sports", price: 7999, originalPrice: 9499, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Untitledjpg.jpg" },
    { id: 48, name: "X Lows Carbon", brand: "comet", type: "sneaker", price: 7499, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Untitled-4_8.jpg" },
    { id: 49, name: "Trail Blazer GTX", brand: "comet", type: "sports", price: 9999, originalPrice: 12499, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Untitled-4_9_2a1f807b-3fa5-4b06-bc29-61bd73137940.jpg" },
    { id: 50, name: "Nova Lite Walker", brand: "comet", type: "casual", price: 4499, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Untitled-2_2_1.jpg" },
    { id: 51, name: "Cosmic Flex", brand: "comet", type: "running", price: 5999, originalPrice: 7499, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/new_lat.jpg" },
    { id: 52, name: "APEX Pro Ultra", brand: "comet", type: "running", price: 10999, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/skribble_final_lateral_1-min.jpg" },
    { id: 53, name: "Street Cruiser", brand: "comet", type: "lifestyle", price: 5499, originalPrice: 6499, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/lateralds.jpg" },
    { id: 54, name: "AEON V3 Boost", brand: "comet", type: "sneaker", price: 8999, originalPrice: null, image: "https://cdn.shopify.com/s/files/1/0738/5559/8899/files/Lateral_78cdb0d3-0fa5-40bc-8063-de700d0c2381.jpg" },
];



// ======================
// STATE
// ======================
let cart = [];
let filterState = { brands: [], types: [], discountOnly: false, sort: 'default', search: '' };

// ======================
// DOM ELEMENTS
// ======================
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

const themeToggle = $('#theme-toggle');
const themeIcon = $('#theme-icon');
const productContainer = $('#product-container');
const productCountText = $('#product-count-text');
const cartToggleBtn = $('#cart-toggle');
const cartOverlay = $('#cart-overlay');
const cartSidebar = $('#cart-sidebar');
const closeCartBtn = $('#close-cart');
const cartItemsContainer = $('#cart-items');
const cartCount = $('#cart-count');
const cartHeaderCount = $('#cart-header-count');
const cartSubtotal = $('#cart-subtotal');
const cartShipping = $('#cart-shipping');
const cartTotalPrice = $('#cart-total-price');
const emptyCartMsg = $('#empty-cart-msg');
const toastContainer = $('#toast-container');
const searchToggle = $('#search-toggle');
const searchOverlay = $('#search-overlay');
const searchClose = $('#search-close');
const searchInput = $('#search-input');
const checkoutOverlay = $('#checkout-overlay');
const checkoutBtn = $('#checkout-btn');
const checkoutTotal = $('#checkout-total');
const mobileMenuToggle = $('#mobile-menu-toggle');
const mobileMenuOverlay = $('#mobile-menu-overlay');
const mobileMenu = $('#mobile-menu');
const mobileMenuClose = $('#mobile-menu-close');
const mobileSort = $('#mobile-sort');
const mobileFilterToggle = $('#mobile-filter-toggle');
const filterSidebar = $('#filter-sidebar');

// ======================
// HELPERS
// ======================
function formatINR(num) {
    return '₹' + num.toLocaleString('en-IN');
}

function discountPercent(original, current) {
    return Math.round(((original - current) / original) * 100);
}

// ======================
// THEME
// ======================
function initTheme() {
    const saved = localStorage.getItem('theme');
    if (saved === 'light') {
        document.body.classList.remove('dark-mode');
        themeIcon.classList.replace('fa-sun', 'fa-moon');
    }
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    themeIcon.classList.replace(isDark ? 'fa-moon' : 'fa-sun', isDark ? 'fa-sun' : 'fa-moon');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
});

// ======================
// SEARCH
// ======================
searchToggle.addEventListener('click', () => {
    searchOverlay.classList.add('active');
    searchInput.focus();
});

searchClose.addEventListener('click', () => {
    searchOverlay.classList.remove('active');
});

searchOverlay.addEventListener('click', (e) => {
    if (e.target === searchOverlay) {
        searchOverlay.classList.remove('active');
    }
});

searchInput.addEventListener('input', (e) => {
    filterState.search = e.target.value.toLowerCase();
    renderProducts();
});

searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        searchOverlay.classList.remove('active');
        document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
    }
});

// ======================
// MOBILE MENU
// ======================
mobileMenuToggle.addEventListener('click', () => {
    mobileMenu.classList.add('active');
    mobileMenuOverlay.classList.add('active');
});

function closeMobileMenu() {
    mobileMenu.classList.remove('active');
    mobileMenuOverlay.classList.remove('active');
}

mobileMenuClose.addEventListener('click', closeMobileMenu);
mobileMenuOverlay.addEventListener('click', closeMobileMenu);

$$('.mobile-nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const brand = link.dataset.filter;
        filterState.brands = brand === 'all' ? [] : [brand];
        // Sync sidebar checkboxes
        $$('input[name="brand"]').forEach(cb => cb.checked = filterState.brands.includes(cb.value));
        closeMobileMenu();
        renderProducts();
    });
});

// ======================
// MOBILE FILTER SIDEBAR
// ======================
mobileFilterToggle.addEventListener('click', () => {
    filterSidebar.classList.toggle('active');
    mobileMenuOverlay.classList.toggle('active');
});

// ======================
// FILTER LOGIC
// ======================

// --- Sort radios ---
$$('input[name="sort"]').forEach(radio => {
    radio.addEventListener('change', () => {
        filterState.sort = radio.value;
        renderProducts();
    });
});

// --- Mobile sort ---
mobileSort.addEventListener('change', () => {
    filterState.sort = mobileSort.value;
    // Sync desktop radios
    $$('input[name="sort"]').forEach(r => r.checked = r.value === filterState.sort);
    renderProducts();
});

// --- Brand checkboxes ---
$$('input[name="brand"]').forEach(cb => {
    cb.addEventListener('change', () => {
        filterState.brands = [...$$('input[name="brand"]:checked')].map(c => c.value);
        renderProducts();
    });
});

// --- Type checkboxes ---
$$('input[name="type"]').forEach(cb => {
    cb.addEventListener('change', () => {
        filterState.types = [...$$('input[name="type"]:checked')].map(c => c.value);
        renderProducts();
    });
});

// --- Discount checkbox ---
$$('input[name="discount"]').forEach(cb => {
    cb.addEventListener('change', () => {
        filterState.discountOnly = cb.checked;
        renderProducts();
    });
});

// --- Clear all ---
$('#clear-filters').addEventListener('click', () => {
    filterState = { brands: [], types: [], discountOnly: false, sort: 'default', search: '' };
    $$('input[name="brand"], input[name="type"], input[name="discount"]').forEach(cb => cb.checked = false);
    $$('input[name="sort"]').forEach(r => r.checked = r.value === 'default');
    mobileSort.value = 'default';
    searchInput.value = '';
    renderProducts();
});

// --- Nav links ---
$$('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        $$('.nav-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        const brand = link.dataset.filter;
        filterState.brands = brand === 'all' ? [] : [brand];
        $$('input[name="brand"]').forEach(cb => cb.checked = filterState.brands.includes(cb.value));
        renderProducts();
        document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
    });
});

// --- Category chips ---
$$('.category-chip').forEach(chip => {
    chip.addEventListener('click', () => {
        $$('.category-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');

        if (chip.dataset.filter) {
            const brand = chip.dataset.filter;
            filterState.brands = brand === 'all' ? [] : [brand];
            filterState.types = [];
            $$('input[name="brand"]').forEach(cb => cb.checked = filterState.brands.includes(cb.value));
            $$('input[name="type"]').forEach(cb => cb.checked = false);
        } else if (chip.dataset.type) {
            filterState.types = [chip.dataset.type];
            filterState.brands = [];
            $$('input[name="type"]').forEach(cb => cb.checked = filterState.types.includes(cb.value));
            $$('input[name="brand"]').forEach(cb => cb.checked = false);
        }
        renderProducts();
    });
});

// ======================
// RENDER PRODUCTS
// ======================
function getFilteredProducts() {
    let result = [...products];

    // Search
    if (filterState.search) {
        result = result.filter(p =>
            p.name.toLowerCase().includes(filterState.search) ||
            p.brand.toLowerCase().includes(filterState.search) ||
            p.type.toLowerCase().includes(filterState.search)
        );
    }
    // Brand
    if (filterState.brands.length) {
        result = result.filter(p => filterState.brands.includes(p.brand));
    }
    // Type
    if (filterState.types.length) {
        result = result.filter(p => filterState.types.includes(p.type));
    }
    // Discount
    if (filterState.discountOnly) {
        result = result.filter(p => p.originalPrice !== null);
    }
    // Sort
    switch (filterState.sort) {
        case 'low-high': result.sort((a, b) => a.price - b.price); break;
        case 'high-low': result.sort((a, b) => b.price - a.price); break;
        case 'discount':
            result.sort((a, b) => {
                const da = a.originalPrice ? discountPercent(a.originalPrice, a.price) : 0;
                const db = b.originalPrice ? discountPercent(b.originalPrice, b.price) : 0;
                return db - da;
            });
            break;
    }

    return result;
}

function renderProducts() {
    const filtered = getFilteredProducts();
    productCountText.textContent = `Showing ${filtered.length} product${filtered.length !== 1 ? 's' : ''}`;
    productContainer.innerHTML = '';

    if (filtered.length === 0) {
        productContainer.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:4rem;color:var(--text-secondary);font-weight:600;">No products found. Try adjusting your filters.</div>';
        return;
    }

    filtered.forEach(product => {
        const hasDiscount = product.originalPrice !== null;
        const discountPct = hasDiscount ? discountPercent(product.originalPrice, product.price) : 0;

        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <div class="product-image-container">
                ${hasDiscount ? `<span class="discount-badge">${discountPct}% OFF</span>` : ''}
                <img src="${product.image}" loading="lazy" alt="${product.name}" class="product-img"
                     onerror="this.src='https://placehold.co/600x600/1a1a1a/666/png?text=${encodeURIComponent(product.name).replace(/'/g, '%27')}'">
            </div>
            <div class="product-info">
                <div class="product-brand">${product.brand}</div>
                <h3 class="product-name">${product.name}</h3>
                <div class="product-price-row">
                    <span class="product-price">${formatINR(product.price)}</span>
                    ${hasDiscount ? `<span class="product-original-price">${formatINR(product.originalPrice)}</span>` : ''}
                    ${hasDiscount ? `<span class="product-discount-pct">${discountPct}% off</span>` : ''}
                </div>
                <div class="product-sizes">
                    <div class="size-label">Size (UK)</div>
                    <div class="size-chips">
                        <span class="size-chip" onclick="event.stopPropagation(); Array.from(this.parentElement.children).forEach(c => c.classList.remove('active')); this.classList.add('active');">7</span>
                        <span class="size-chip" onclick="event.stopPropagation(); Array.from(this.parentElement.children).forEach(c => c.classList.remove('active')); this.classList.add('active');">8</span>
                        <span class="size-chip active" onclick="event.stopPropagation(); Array.from(this.parentElement.children).forEach(c => c.classList.remove('active')); this.classList.add('active');">9</span>
                        <span class="size-chip" onclick="event.stopPropagation(); Array.from(this.parentElement.children).forEach(c => c.classList.remove('active')); this.classList.add('active');">10</span>
                        <span class="size-chip" onclick="event.stopPropagation(); Array.from(this.parentElement.children).forEach(c => c.classList.remove('active')); this.classList.add('active');">11</span>
                    </div>
                </div>
                <button class="add-to-cart-btn" onclick="event.stopPropagation(); addToCart(${product.id})">
                    <i class="fa-solid fa-bag-shopping"></i> Add to Cart
                </button>
            </div>
        `;
        productContainer.appendChild(card);
    });
}

// ======================
// CART
// ======================
function toggleCart() {
    cartOverlay.classList.toggle('active');
    cartSidebar.classList.toggle('active');
}
cartToggleBtn.addEventListener('click', toggleCart);
closeCartBtn.addEventListener('click', toggleCart);
cartOverlay.addEventListener('click', toggleCart);

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existing = cart.find(item => item.id === productId);

    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    updateCartUI();
    showToast(`${product.name} added to bag!`);
}

function updateCartItemQty(productId, delta) {
    const item = cart.find(i => i.id === productId);
    if (!item) return;
    item.quantity += delta;
    if (item.quantity <= 0) {
        removeFromCart(productId);
    } else {
        updateCartUI();
    }
}

function removeFromCart(productId) {
    cart = cart.filter(i => i.id !== productId);
    updateCartUI();
}

function updateCartUI() {
    const totalItems = cart.reduce((s, i) => s + i.quantity, 0);
    cartCount.textContent = totalItems;
    cartHeaderCount.textContent = `(${totalItems})`;

    // Badge pop
    cartCount.style.transform = 'scale(1.3)';
    setTimeout(() => cartCount.style.transform = 'scale(1)', 200);

    // Render items
    document.querySelectorAll('.cart-item').forEach(el => el.remove());

    if (cart.length === 0) {
        emptyCartMsg.style.display = 'flex';
        cartSubtotal.textContent = '₹0';
        cartShipping.textContent = 'FREE';
        cartTotalPrice.textContent = '₹0';
        return;
    }

    emptyCartMsg.style.display = 'none';
    let subtotal = 0;

    cart.forEach(item => {
        subtotal += item.price * item.quantity;
        const el = document.createElement('div');
        el.className = 'cart-item';
        el.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="cart-item-img" onerror="this.src='https://placehold.co/72x72/1a1a1a/666/png?text=Shoe'">
            <div class="cart-item-details">
                <div class="cart-item-brand">${item.brand}</div>
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${formatINR(item.price)}</div>
            </div>
            <div class="cart-item-actions">
                <button class="qty-btn" onclick="updateCartItemQty(${item.id}, 1)">+</button>
                <span class="cart-item-qty">${item.quantity}</span>
                <button class="qty-btn" onclick="updateCartItemQty(${item.id}, -1)">−</button>
                <span class="remove-item-btn" onclick="removeFromCart(${item.id})">Remove</span>
            </div>
        `;
        cartItemsContainer.insertBefore(el, emptyCartMsg);
    });

    const shipping = subtotal >= 2999 ? 0 : 199;
    cartSubtotal.textContent = formatINR(subtotal);
    cartShipping.textContent = shipping === 0 ? 'FREE' : formatINR(shipping);
    cartTotalPrice.textContent = formatINR(subtotal + shipping);
}

// ======================
// CHECKOUT FLOW
// ======================
checkoutBtn.addEventListener('click', () => {
    if (cart.length === 0) return;
    toggleCart();
    openCheckout();
});

function openCheckout() {
    checkoutOverlay.classList.add('active');
    showCheckoutStep(1);
    const total = cart.reduce((s, i) => s + i.price * i.quantity, 0);
    const shipping = total >= 2999 ? 0 : 199;
    checkoutTotal.textContent = formatINR(total + shipping);
}

function showCheckoutStep(step) {
    [1, 2, 3].forEach(s => {
        const el = document.getElementById(`checkout-step-${s}`);
        el.classList.toggle('hidden', s !== step);
    });
}

// Close checkout
$$('.checkout-close').forEach(btn => {
    btn.addEventListener('click', () => checkoutOverlay.classList.remove('active'));
});

// Step 1 -> Step 2
$('#shipping-form').addEventListener('submit', (e) => {
    e.preventDefault();
    showCheckoutStep(2);
});

// Step 2 -> Step 3 (confirmation)
$('#payment-form').addEventListener('submit', (e) => {
    e.preventDefault();
    // Generate a random order ID
    const orderId = 'KC-' + Math.random().toString(36).substring(2, 10).toUpperCase();
    $('#order-id').textContent = `Order ID: ${orderId}`;
    showCheckoutStep(3);
    // Clear cart
    cart = [];
    updateCartUI();
});

// Continue shopping
$('#continue-shopping').addEventListener('click', () => {
    checkoutOverlay.classList.remove('active');
});

// ======================
// TOAST
// ======================
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class="fa-solid fa-circle-check"></i><span>${message}</span>`;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// ======================
// TRACK ORDER
// ======================
const trackOverlay = $('#track-overlay');
const trackLink = $('#footer-track-order');
const trackClose = $('#track-close');
const trackForm = $('#track-form');
const trackResult = $('#track-result');

if (trackLink) {
    trackLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (trackResult) trackResult.style.display = 'none';
        if (trackForm) trackForm.style.display = 'flex';
        if (trackOverlay) trackOverlay.classList.add('active');
    });
}
if (trackClose) {
    trackClose.addEventListener('click', () => {
        if (trackOverlay) trackOverlay.classList.remove('active');
    });
}
if (trackForm) {
    trackForm.addEventListener('submit', (e) => {
        e.preventDefault();
        trackForm.style.display = 'none';
        if (trackResult) trackResult.style.display = 'block';
    });
}

// ======================
// INIT
// ======================
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    renderProducts();
});